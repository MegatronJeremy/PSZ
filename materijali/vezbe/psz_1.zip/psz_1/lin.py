import pandas as pd
dataset = pd.read_csv('data_lin.csv')
x = dataset['Sugar']
y = dataset['Diabetes']

# import matplotlib.pyplot as plt
# plt.scatter(x, y)
# plt.show()

from sklearn.model_selection import train_test_split

x_train, x_test, y_train, y_test = train_test_split(x,y,test_size=0.25)

from sklearn.linear_model import LinearRegression
model = LinearRegression()

model.fit(x_train.to_numpy().reshape(-1,1), y_train)

import matplotlib.pyplot as plt
plt.scatter(x_train, y_train)
plt.plot(x_train,model.predict(x_train.to_numpy().reshape(-1,1)), color='blue', linewidth=3)
xx = x_train.to_numpy().reshape(-1,1)

xxx = []
for i in range(len(xx)):
    xxx.append(xx[i]*model.coef_[0] + model.intercept_)
plt.plot(xx, xxx, color='orange', linewidth=1)
plt.show()

print("Coeff:", model.score(x_test.to_numpy().reshape(-1,1), y_test))
from sklearn.metrics import r2_score
print("Coeff2:", r2_score(y_test, model.predict(x_test.to_numpy().reshape(-1,1))))



