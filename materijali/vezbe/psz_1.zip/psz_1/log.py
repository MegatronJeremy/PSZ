from random import shuffle
import pandas as pd
dataset = pd.read_csv('data_log.csv')
x = dataset['Sugar']
y = dataset['Diabetes']
from sklearn.model_selection import train_test_split

x_train, x_test, y_train, y_test = train_test_split(x,y,test_size=0.25, shuffle=False)

from sklearn.linear_model import LogisticRegression
model = LogisticRegression()
model.fit(x_train.to_numpy().reshape(-1,1), y_train)

import numpy as np
from scipy.special import expit
import matplotlib.pyplot as plt

plt.scatter(x_train, y_train, color='black')
x_range = np.linspace(-5, 20, 300)
sigmoid_values  =expit(x_range*model.coef_ + model.intercept_).reshape(-1,1)
plt.plot(x_range, sigmoid_values, color='red', linewidth=1)
plt.show()

print("Score:", model.score(x_test.to_numpy().reshape(-1,1), y_test))

import matplotlib.pyplot as plt
from sklearn.metrics import ConfusionMatrixDisplay

disp = ConfusionMatrixDisplay.from_predictions(y_test, model.predict(x_test.to_numpy().reshape(-1,1)))

plt.show()
