import pandas as pd
dataset = pd.read_csv('data_svm.csv')
x = dataset[['Height', 'Weight']]
y = dataset['Gender']
from sklearn.model_selection import train_test_split

x_train, x_test, y_train, y_test = train_test_split(x,y,test_size=0.25)

import matplotlib.pyplot as plt

color = []
for i in y_train.values:
    if(i==0):
        color.append('blue')
    else:
        color.append('red')

plt.scatter(x_train['Height'], x_train['Weight'], c=color)
plt.show()

from sklearn.svm import SVC
model = SVC()
model.fit(x_train, y_train)

import numpy as np
def plot_svc_decision_function(model, ax=None, plot_support=True):
    """Plot the decision function for a 2D SVC"""
    if ax is None:
        ax = plt.gca()
    xlim = ax.get_xlim()
    ylim = ax.get_ylim()
    
    # create grid to evaluate model
    x = np.linspace(xlim[0], xlim[1], 30)
    y = np.linspace(ylim[0], ylim[1], 30)
    Y, X = np.meshgrid(y, x)
    xy = np.vstack([X.ravel(), Y.ravel()]).T
    P = model.decision_function(xy).reshape(X.shape)
    
    # plot decision boundary and margins
    ax.contour(X, Y, P, colors='k',
               levels=[-1, 0, 1], alpha=0.5,
               linestyles=['--', '-', '--'])
    
    # plot support vectors
    if plot_support:
        ax.scatter(model.support_vectors_[:, 0],
                   model.support_vectors_[:, 1],
                   s=300, linewidth=1, facecolors='none')
    ax.set_xlim(xlim)
    ax.set_ylim(ylim)

plt.scatter(x_train['Height'], x_train['Weight'], c=color)
plot_svc_decision_function(model)
plt.show()

print("Score:", model.score(x_test, y_test))

import matplotlib.pyplot as plt
from sklearn.metrics import ConfusionMatrixDisplay

disp = ConfusionMatrixDisplay.from_predictions(y_test, model.predict(x_test))

plt.show()

