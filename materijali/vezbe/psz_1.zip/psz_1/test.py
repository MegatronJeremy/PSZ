msg = "Hello world"
print(msg)

import numpy as np

array = np.array([1,5,2,7])
sorted_array = np.sort(array)[::-1]
print(sorted_array)

matrix = np.array([[1,2,3], [4,5,6]])
print(matrix)