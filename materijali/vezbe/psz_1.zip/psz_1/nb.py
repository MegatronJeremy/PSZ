from random import shuffle
import pandas as pd

dataset = pd.read_csv('data_nb.csv')
x = dataset['Color']
y = dataset['Gender']

# print(x)
# print(y)

from sklearn.model_selection import train_test_split

x_train, x_test, y_train, y_test = train_test_split(x,y,test_size=0.25)

from sklearn.naive_bayes import BernoulliNB
model = BernoulliNB(alpha=0, force_alpha=True)

model.fit(x_train.to_numpy().reshape(-1, 1), y_train)

predictions = model.predict(x_test.to_numpy().reshape(-1,1))

print("Inputs", x_test)
print("Predictions:", predictions)
print("True:", y_test)

print("%", model.predict_proba(x_test.to_numpy().reshape(-1,1)))

print("Score:", model.score(x_test.to_numpy().reshape(-1,1), y_test))

import matplotlib.pyplot as plt
from sklearn.metrics import ConfusionMatrixDisplay

disp = ConfusionMatrixDisplay.from_predictions(y_test, predictions)

plt.show()