import pandas as pd
dataset = pd.read_csv('data.csv')

dataset['Salary'] = dataset['Salary'].fillna(dataset['Salary'].mean())
dataset['Area'] = dataset['Area'].fillna(dataset["Area"].mode()[0])

print(dataset)

# from sklearn.preprocessing import LabelEncoder
# enc = LabelEncoder()
# dataset['Area']=enc.fit_transform(dataset['Area'])
# print(dataset)

area_ohe = pd.get_dummies(dataset['Area'], 
prefix='Area', dtype=int)
married_ohe = pd.get_dummies(dataset['Married'], 
prefix='Married', dtype=int)
car_ohe = pd.get_dummies(dataset['Car'], 
prefix='Car', dtype=int)

dataset = pd.merge(left=dataset, right=area_ohe, left_index=True, right_index=True)
dataset = pd.merge(left=dataset, right=married_ohe, left_index=True, right_index=True)
dataset = pd.merge(left=dataset, right=car_ohe, left_index=True, right_index=True)

dataset = dataset.drop('Area', axis=1)
dataset = dataset.drop('Married', axis=1)
dataset = dataset.drop('Car', axis=1)

x = dataset[['Age', 'Salary', 'Area_City', 'Area_Country', 'Married_Yes', 'Married_No']]
y = dataset[['Car_Yes', 'Car_No']]

print(dataset)

from sklearn.ensemble import ExtraTreesClassifier
model = ExtraTreesClassifier()
model.fit(x, y)
print(model.feature_importances_)

x = x[['Age', 'Salary', 'Married_No', 'Married_Yes']]

import seaborn as sb
import matplotlib.pyplot as plt

sb.heatmap(x.corr(), annot=True, cmap='RdYlGn')
plt.show()

x = x[['Age', 'Salary', 'Married_No']]
y = y['Car_No']

import numpy as np
from sklearn.preprocessing import MinMaxScaler

dataX = np.asarray(x[['Age', 'Salary', 'Married_No']])
scaler = MinMaxScaler()
x = scaler.fit_transform(dataX)

# print(x)

from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y)

from sklearn.neighbors import KNeighborsClassifier
model = KNeighborsClassifier(n_neighbors=5, weights='distance')
model.fit(x_train, y_train)

y_pred = model.predict(x_test)

print('features:', x_test)
print('pred:',y_pred)

from sklearn import  metrics
print("Acc:", metrics.accuracy_score(y_test, y_pred))
