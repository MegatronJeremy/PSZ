import pandas as pd
dataset  =pd.read_csv('data_knn_class.csv')

x = dataset[['Height', 'Weight']]
y = dataset['BMI']

from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=1, shuffle = False)

import matplotlib.pyplot as plt
colors = []
for i in y_train.values:
    if(i==0): colors.append("green")
    else: colors.append("red")
plt.scatter(x_train['Height'], x_train['Weight'],
 c=colors)
plt.scatter(x_test["Height"], x_test["Weight"], c=['orange'])
plt.show()

from sklearn.neighbors import KNeighborsClassifier
model = KNeighborsClassifier(n_neighbors=3, weights='distance')
model.fit(x_train, y_train)

print(model.predict(x_test))
