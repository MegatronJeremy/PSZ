import pandas as pd
dataset  =pd.read_csv('data_knn_reg.csv')

x = dataset[['Height', 'Weight']]
y = dataset['BMI']

from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=1, shuffle = False)

import matplotlib.pyplot as plt

plt.scatter(x_train['Height'], x_train['Weight'],
 c=['blue'])
plt.scatter(x_test["Height"], x_test["Weight"], c=['orange'])
plt.show()

from sklearn.neighbors import KNeighborsRegressor
model = KNeighborsRegressor(n_neighbors=2)
model.fit(x_train, y_train)

print(model.predict(x_test))
