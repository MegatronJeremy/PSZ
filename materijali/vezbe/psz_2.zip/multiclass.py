# print("Hello")
from sklearn import datasets
import pandas as pd

iris = datasets.load_iris()
x = pd.DataFrame(iris.data, columns=iris.feature_names)
y = iris.target
# print(x)
# print(y)
import seaborn as sb
import matplotlib.pyplot as plt

sb.scatterplot(data=x, x='sepal length (cm)', 
                y = 'sepal width (cm)', hue = y)
plt.show()
sb.scatterplot(data=x, x='petal length (cm)', 
                y = 'petal width (cm)', hue = y)
plt.show()

from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y)

from sklearn.naive_bayes import BernoulliNB, GaussianNB
from sklearn.metrics import accuracy_score
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC

models = [BernoulliNB(), GaussianNB(), 
LogisticRegression(multi_class='ovr'), SVC() ]

for index, model in enumerate(models):
    model.fit(x_train, y_train)
    predictions = model.predict(x_test)

    print("Accuracy " + model.__class__.__name__ + " model: ",
        accuracy_score(y_test, predictions))
